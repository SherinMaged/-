#!/usr/bin/env python3
"""Transcribe Arabic speech from a WAV file using the Vosk MGB-2 model.

Usage:
    python src/transcribe.py audio.wav
    python src/transcribe.py audio.wav --model /path/to/vosk-model-ar-mgb2-0.4
"""

import argparse
import json
import sys
import wave
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_MODEL_DIR = PROJECT_ROOT / "vosk-model-ar-mgb2-0.4"

CHUNK_SIZE = 4000


def main() -> int:
    parser = argparse.ArgumentParser(description="Transcribe a WAV file with Vosk (Arabic MGB-2 model)")
    parser.add_argument("audio", help="Path to a WAV file (mono, 16 kHz recommended)")
    parser.add_argument(
        "--model",
        default=str(DEFAULT_MODEL_DIR),
        help=f"Path to the Vosk model directory (default: {DEFAULT_MODEL_DIR.name})",
    )
    parser.add_argument("--words", action="store_true", help="Print word-level timestamps")
    args = parser.parse_args()

    try:
        from vosk import KaldiRecognizer, Model, SetLogLevel
    except ImportError:
        sys.exit("Vosk is not installed. Run: pip install -r requirements.txt")

    model_dir = Path(args.model)
    if not model_dir.is_dir():
        sys.exit(
            f"Model not found: {model_dir}\n"
            f"Download it first: python src/download_model.py"
        )

    audio_path = Path(args.audio)
    if not audio_path.is_file():
        sys.exit(f"Audio file not found: {audio_path}")

    SetLogLevel(-1)
    print(f"Loading model from {model_dir} ...", file=sys.stderr)
    model = Model(str(model_dir))

    try:
        wf = wave.open(str(audio_path), "rb")
    except (wave.Error, OSError) as exc:
        sys.exit(f"Cannot open WAV file: {exc}")

    if wf.getnchannels() != 1:
        sys.exit(f"Audio must be mono ({wf.getnchannels()} channels found). Convert with:\n"
                 f"  ffmpeg -i input.wav -ac 1 -ar 16000 output.wav")

    rec = KaldiRecognizer(model, wf.getframerate())
    if args.words:
        rec.SetWords(True)

    while True:
        data = wf.readframes(CHUNK_SIZE)
        if not data:
            break
        rec.AcceptWaveform(data)
    wf.close()

    result = json.loads(rec.FinalResult())
    text = result.get("text", "").strip()

    if args.words:
        json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
        print()
    else:
        print(text)

    return 0


if __name__ == "__main__":
    sys.exit(main())
