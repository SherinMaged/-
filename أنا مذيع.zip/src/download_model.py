#!/usr/bin/env python3
"""Download and extract the vosk-model-ar-mgb2-0.4 model into the project root.

Usage:
    python src/download_model.py
"""

import sys
import urllib.request
import zipfile
from pathlib import Path

MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-ar-mgb2-0.4.zip"
PROJECT_ROOT = Path(__file__).resolve().parent.parent


def report(block_count: int, block_size: int, total_size: int) -> None:
    if total_size <= 0:
        return
    downloaded = min(block_count * block_size, total_size)
    percent = downloaded * 100 // total_size
    mb = downloaded / (1024 * 1024)
    total_mb = total_size / (1024 * 1024)
    sys.stderr.write(f"\rDownloading... {percent:3d}%  ({mb:.1f}/{total_mb:.1f} MB)")
    sys.stderr.flush()


def main() -> int:
    zip_path = PROJECT_ROOT / Path(MODEL_URL).name
    extract_dir = PROJECT_ROOT / zip_path.stem

    if extract_dir.is_dir():
        print(f"Model already exists: {extract_dir}")
        return 0

    print(f"Downloading {MODEL_URL}")
    try:
        urllib.request.urlretrieve(MODEL_URL, zip_path, reporthook=report)
    except OSError as exc:
        sys.stderr.write("\n")
        sys.exit(f"Download failed: {exc}")
    sys.stderr.write("\n")

    print(f"Extracting {zip_path.name} ...")
    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(PROJECT_ROOT)

    zip_path.unlink()
    print(f"Done: {extract_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
